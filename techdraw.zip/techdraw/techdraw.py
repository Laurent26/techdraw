﻿# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

import bpy

from bpy.props import *

from bpy.types import AddonPreferences

import sys

import bpy
import bpy, csv
import mathutils
import os
from math import *
import math
from bpy.types import Operator
from bpy.props import FloatVectorProperty
from bpy_extras.object_utils import AddObjectHelper, object_data_add
from mathutils import Vector
import bpy
import bmesh
import mathutils
import os
from math import *
from bpy.props import (
        BoolProperty,
        EnumProperty,
        FloatProperty,
        IntProperty,
        )


class OBJECT_OT_ApplyButton(bpy.types.Operator):
    bl_idname = "apply.apply"
    bl_label = "Add view"
    
    def execute(self, context):
                
        result = not bpy.context.scene.Target is None
        result = result and (bpy.context.scene.Target.name in context.view_layer.objects)
        
        if result == True:
            target_obj = bpy.context.scene.Target
            dim_draw = bpy.context.scene.draw_distance
            
            xValueC = bpy.context.scene.cursor.location[0]
            yValueC = bpy.context.scene.cursor.location[1]
            zValueC = bpy.context.scene.cursor.location[2]        
            
            bpy.ops.object.select_all(action='DESELECT')        
            target_obj.select_set(state=True)
            bpy.context.view_layer.objects.active = target_obj     
            
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
            
            #locOrigX = bpy.context.object.location [0]
            #locOrigY = bpy.context.object.location [1]
            #locOrigZ = bpy.context.object.location [2]        
            
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
            
            xmin = bpy.context.object.location [0]
            xmax = bpy.context.object.location [0]
            ymin = bpy.context.object.location [1]
            ymax = bpy.context.object.location [1]
            zmin = bpy.context.object.location [2]
            zmax = bpy.context.object.location [2]
            
            matrix = target_obj.matrix_world
            vertObj = target_obj.data.vertices        
                    
            for v in vertObj:
                vPos = matrix@v.co
                xV = vPos[0]
                yV = vPos[1]
                zV = vPos[2]
                if xV < xmin:
                    xmin = xV
                if xV > xmax:
                    xmax = xV
                if yV < ymin:
                    ymin = yV
                if yV > ymax:
                    ymax = yV
                if zV < zmin:
                    zmin = zV
                if zV > zmax:
                    zmax = zV
            
            dimX = bpy.context.object.dimensions[0]
            dimY = bpy.context.object.dimensions[1]
            dimZ = bpy.context.object.dimensions[2]
            
            bpy.context.scene.cursor.location[0] = xmax - (dimX/2)
            bpy.context.scene.cursor.location[1] = ymax - (dimY/2)
            bpy.context.scene.cursor.location[2] = zmax - (dimZ/2)
            
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')

            locX = bpy.context.object.location [0]
            locY = bpy.context.object.location [1]
            locZ = bpy.context.object.location [2]        
            
            if bpy.context.scene.lv_bool:
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(0, 0, 0)})
                bpy.context.object.location [0] = locX + dim_draw + dimX/2 + dimZ/2
                bpy.context.object.rotation_euler [1] = pi/2
                
            bpy.ops.object.select_all(action='DESELECT')        
            target_obj.select_set(state=True)
            bpy.context.view_layer.objects.active = target_obj
            
            if bpy.context.scene.rv_bool:
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(0, 0, 0)})
                bpy.context.object.location [0] = locX - dim_draw - dimX/2 - dimZ/2
                bpy.context.object.rotation_euler [1] = -pi/2
                
            bpy.ops.object.select_all(action='DESELECT')        
            target_obj.select_set(state=True)
            bpy.context.view_layer.objects.active = target_obj
            
            if bpy.context.scene.bv_bool:
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(0, 0, 0)})
                bpy.context.object.location [0] = locX + dim_draw + dimX/2 + dimZ + dim_draw + dimX/2
                bpy.context.object.rotation_euler [1] = pi
                
            bpy.ops.object.select_all(action='DESELECT')        
            target_obj.select_set(state=True)
            bpy.context.view_layer.objects.active = target_obj
            
            if bpy.context.scene.dv_bool:
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(0, 0, 0)})
                bpy.context.object.location [1] = locY + dim_draw + dimY/2 + dimZ/2
                bpy.context.object.rotation_euler [0] = -pi/2
                
            bpy.ops.object.select_all(action='DESELECT')        
            target_obj.select_set(state=True)
            bpy.context.view_layer.objects.active = target_obj
            
            if bpy.context.scene.uv_bool:
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(0, 0, 0)})
                bpy.context.object.location [1] = locY - dim_draw - dimY/2 - dimZ/2
                bpy.context.object.rotation_euler [0] = pi/2
                
            bpy.ops.object.select_all(action='DESELECT')        
            target_obj.select_set(state=True)
            bpy.context.view_layer.objects.active = target_obj
            
            if bpy.context.scene.drv_bool:
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(0, 0, 0)})
                bpy.context.object.location [0] = locX + dim_draw + dimX/2 + dimZ/2
                bpy.context.object.location [1] = locY - dim_draw - dimY/2 - dimZ/2
                bpy.context.object.rotation_euler [0] = pi/4
                bpy.context.object.rotation_euler [1] = pi/4
                
            bpy.ops.object.select_all(action='DESELECT')        
            target_obj.select_set(state=True)
            bpy.context.view_layer.objects.active = target_obj
            
            if bpy.context.scene.dlv_bool:
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(0, 0, 0)})
                bpy.context.object.location [0] = locX - dim_draw - dimX/2 - dimZ/2
                bpy.context.object.location [1] = locY - dim_draw - dimY/2 - dimZ/2
                bpy.context.object.rotation_euler [0] = pi/4
                bpy.context.object.rotation_euler [1] = -pi/4
                
            bpy.ops.object.select_all(action='DESELECT')        
            target_obj.select_set(state=True)
            bpy.context.view_layer.objects.active = target_obj
            
            if bpy.context.scene.urv_bool:
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(0, 0, 0)})
                bpy.context.object.location [0] = locX + dim_draw + dimX/2 + dimZ/2
                bpy.context.object.location [1] = locY + dim_draw + dimY/2 + dimZ/2
                bpy.context.object.rotation_euler [0] = -pi/4
                bpy.context.object.rotation_euler [1] = pi/4
                
            bpy.ops.object.select_all(action='DESELECT')        
            target_obj.select_set(state=True)
            bpy.context.view_layer.objects.active = target_obj
            
            if bpy.context.scene.ulv_bool:
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(0, 0, 0)})
                bpy.context.object.location [0] = locX - dim_draw - dimX/2 - dimZ/2
                bpy.context.object.location [1] = locY + dim_draw + dimY/2 + dimZ/2
                bpy.context.object.rotation_euler [0] = -pi/4
                bpy.context.object.rotation_euler [1] = -pi/4
                
            bpy.ops.object.select_all(action='DESELECT')        
            target_obj.select_set(state=True)
            bpy.context.view_layer.objects.active = target_obj
            
            #bpy.context.scene.cursor.location[0] = locOrigX
            #bpy.context.scene.cursor.location[1] = locOrigY
            #bpy.context.scene.cursor.location[2] = locOrigZ        
            #bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
            
            bpy.context.scene.cursor.location[0] = xValueC
            bpy.context.scene.cursor.location[1] = yValueC
            bpy.context.scene.cursor.location[2] = zValueC
            
            bpy.context.scene.fv_bool = False
            bpy.context.scene.lv_bool = False
            bpy.context.scene.rv_bool = False
            bpy.context.scene.bv_bool = False
            bpy.context.scene.uv_bool = False
            bpy.context.scene.dv_bool = False
            bpy.context.scene.ulv_bool = False
            bpy.context.scene.urv_bool = False
            bpy.context.scene.dlv_bool = False
            bpy.context.scene.drv_bool = False
                    
        return {'FINISHED'}
    

class OBJECT_OT_UpdateButton(bpy.types.Operator):
    bl_idname = "update.update"
    bl_label = "Update view"
    
    def execute(self, context):
        
        bpy.ops.object.make_links_data(type='OBDATA')
        bpy.ops.object.make_single_user(type='SELECTED_OBJECTS', object=True, obdata=True, material=False, animation=False)
        
        return {'FINISHED'}

class OBJECT_OT_AddCameraButton(bpy.types.Operator):
    bl_idname = "cam.cam"
    bl_label = "Add camera"
    
    def execute(self, context):        
        
        resultTarget = not bpy.context.scene.Target is None
        resultTarget = resultTarget and (bpy.context.scene.Target.name in context.view_layer.objects)
        
        if resultTarget == True:
            target_obj = bpy.context.scene.Target
            bpy.ops.object.select_all(action='DESELECT')        
            target_obj.select_set(state=True)
            bpy.context.view_layer.objects.active = target_obj
            xTarget = bpy.context.object.location [0]
            yTarget = bpy.context.object.location [1]
        else:
            xTarget = 0
            yTarget = 0
        
        result = not bpy.context.scene.Collection is None
        if result == True:
            target_collection = bpy.context.scene.Collection        
            nameCollection = target_collection.name
            self.master_collection = bpy.context.scene.collection        
            self.layer_collection = bpy.data.collections[nameCollection]        
            
            bpy.ops.object.camera_add(enter_editmode=False, align='VIEW', location=(xTarget, yTarget, 10), rotation=(0, 0, 0))
            bpy.context.object.name = "Cam_view"
            
            bpy.context.object.data.type = 'ORTHO'
            bpy.context.object.data.ortho_scale = 5
            bpy.ops.object.move_to_collection(collection_index=0, is_new=False, new_collection_name = "")
            self.layer_collection.objects.link(bpy.context.object)
            self.master_collection.objects.unlink(bpy.context.object)
            
            #test = bpy.context.object.name = "test"
            #test = bpy.context.object.name
            #print(test)
            #bpy.ops.object.select_all(action='DESELECT')        
            #bpy.context.object.select_set(state=True)
            #bpy.context.view_layer.objects.active = bpy.context.object
            #bpy.context.scene.camera = bpy.context.object
            
            #print(bpy.context.object.name)
            bpy.context.scene.camera = bpy.data.objects["Cam_view"]            
    
        return {'FINISHED'}
    

class OBJECT_OT_FormatButton(bpy.types.Operator):
    bl_idname = "format.format"
    bl_label = "Add sheets"
    
    def execute(self, context):
        
        scene_collection = bpy.context.view_layer.layer_collection
        bpy.context.view_layer.active_layer_collection = scene_collection

        prefs = bpy.context.preferences.addons['techdraw'].preferences
        
        path = prefs.pathTemplates
        
        formatSheets = bpy.context.scene.format_type        
                
        fileNameForAppend = "FormatSheets.blend\\Collection\\" + formatSheets        
    
        bpy.ops.wm.append(
            filepath="FormatSheets.blend",
            directory=path,
            filename=fileNameForAppend)
        
        return {'FINISHED'}
    

class OBJECT_OT_SFRenderButton(bpy.types.Operator):
    bl_idname = "sfrender.sfrender"
    bl_label = "Update settings"
    
    def execute(self, context):
        
        resultSheets = not bpy.context.scene.Sheets is None
        resultSheets = resultSheets and (bpy.context.scene.Sheets.name in context.view_layer.objects)
        resultCamera = not bpy.context.scene.Camera is None
        print(bpy.context.scene.Camera.name)
        resultCamera = resultCamera and (bpy.context.scene.Camera.name in context.view_layer.objects)
        
        print(resultSheets)
        print(resultCamera)
        
        if (resultSheets == True) and (resultCamera == True):
            
            target_Sheets = bpy.context.scene.Sheets
            target_Camera = bpy.context.scene.Camera
                        
            bpy.ops.object.select_all(action='DESELECT')        
            target_Sheets.select_set(state=True)
            bpy.context.view_layer.objects.active = target_Sheets     
                        
            xdim = bpy.context.object.dimensions [0]
            ydim = bpy.context.object.dimensions [1]
            
            bpy.context.scene.render.resolution_x = 4200
            bpy.context.scene.render.resolution_y = 4200 * (ydim/xdim)

            bpy.ops.object.select_all(action='DESELECT')        
            target_Camera.select_set(state=True)
            bpy.context.view_layer.objects.active = target_Camera

            bpy.context.object.data.ortho_scale = xdim
            
            xLocCam = bpy.context.object.location [0]
            yLocCam = bpy.context.object.location [1]
            
            bpy.ops.object.select_all(action='DESELECT')
            target_Sheets.select_set(state=True)
            bpy.context.view_layer.objects.active = target_Sheets
            
            bpy.context.object.location [0] = xLocCam
            bpy.context.object.location [1] = yLocCam
            
            bpy.ops.object.select_all(action='DESELECT')
        
        return {'FINISHED'}

	
class OB_PT_LSToolsPanel(bpy.types.Panel):
    bl_label = "Layout settings"
    bl_idname = "OB_PT_LSToolsPanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "TechDraw"
    
    #prefs = bpy.context.preferences.addons['techdraw'].preferences
    #print(prefs)
    #result = not prefs is None
    
    #result = False
    #if result == True:
    
    #    path = prefs.pathTemplates
        
    #    print(path)
        
    #    path = path +  "\Templates.dgf"
    #    print(path)
        
        #icons_dir = os.path.join(os.path.dirname(__file__), "icons")
        #for icon in os.listdir(icons_dir):
        #    name, ext = os.path.splitext(icon)
        #    icons.load(name, os.path.join(icons_dir, icon), 'IMAGE')
        
        #icons_dir = os.path.join(os.path.dirname(__file__), "icons")    
        #print(icons_dir + path)
        #filename = os.path.join(os.path.dirname(bpy.data.filepath), "preset.csv")
        #filename = os.path.dirname(bpy.data.filepath)
        #print(os.path.dirname(bpy.data.filepath))
            
        #print(os.path.dirname(bpy.data.filepath))
        #path = filename

        #format_types = [ ["", "", "", 0],
        #                ["", "", "", 1],
        #                ["", "", "", 2]
        #            ]
    #    f_types = [ ["", "", "", 0],
    #                    ["", "", "", 1],
    #                    ["", "", "", 2]
    #                ]

    #    with open(path) as csvfile:
    #        content = csv.reader(csvfile, delimiter=';', dialect='excel')
    #        for i,row in enumerate(content):
    #            #if i == 0: continue            # skip header
    #            x = row [0]
    #            print(x)
    #            f_types[i][0] = str(row [0])
    #            f_types[i][1] = str(row [0])
                
    
    
    
    bpy.types.Scene.Target = PointerProperty(type=bpy.types.Object)

    bpy.types.Scene.Collection = PointerProperty(type=bpy.types.Collection)

    bpy.types.Scene.Sheets = PointerProperty(type=bpy.types.Object)

    bpy.types.Scene.Camera = PointerProperty(type=bpy.types.Object)

    bpy.types.Scene.lv_bool = BoolProperty(
                                          name="", 
                                          description="Left view",
                                          default = False)

    bpy.types.Scene.rv_bool = BoolProperty(
                                          name="", 
                                          description="Right view",
                                          default = False)

    bpy.types.Scene.bv_bool = BoolProperty(
                                          name="", 
                                          description="Back view",
                                          default = False)

    bpy.types.Scene.fv_bool = BoolProperty(
                                          name="", 
                                          description="Front view",
                                          default = False)

    bpy.types.Scene.uv_bool = BoolProperty(
                                          name="", 
                                          description="Up view",
                                          default = False)

    bpy.types.Scene.dv_bool = BoolProperty(
                                          name="", 
                                          description="Down view",
                                          default = False)

    bpy.types.Scene.ulv_bool = BoolProperty(
                                          name="", 
                                          description="3d view",
                                          default = False)

    bpy.types.Scene.urv_bool = BoolProperty(
                                          name="", 
                                          description="3d view",
                                          default = False)

    bpy.types.Scene.dlv_bool = BoolProperty(
                                          name="", 
                                          description="3d view",
                                          default = False)

    bpy.types.Scene.drv_bool = BoolProperty(
                                          name="", 
                                          description="3d view",
                                          default = False)    

    bpy.types.Scene.draw_distance = FloatProperty(
                                          name="Draw Distance", 
                                          description="Distance between view",
                                          default = 1.0)
                                          
    format_types = [ ("A3_Landscape", "A3_Landscape", "", 0),
                    ("Collection 2", "Collection 2", "", 1),
                    ("Collection 3", "Collection 3", "", 2)
                  ]
    
    bpy.types.Scene.format_type = bpy.props.EnumProperty(items=format_types, 
                                                            name="Formats:",
                                                            default=format_types[0][0])
    
 
    def draw(self, context):
                     
        self.layout.prop(context.scene, "Target")
        
        layout = self.layout
        row = layout.row()
        layout.label(text="View:", icon='LIGHT_HEMI')
        
        row = layout.row()
        col = row.column()
        col.prop(context.scene, "ulv_bool")
        col = row.column()
        col.prop(context.scene, "dv_bool")
        col = row.column()                       
        col.prop(context.scene, "urv_bool")
        
        row = layout.row()
        col = row.column()
        col.prop(context.scene, "rv_bool")
        col = row.column()
        col.prop(context.scene, "fv_bool")
        col = row.column()
        col.prop(context.scene, "lv_bool")
        col = row.column()                       
        col.prop(context.scene, "bv_bool")
        
        row = layout.row()
        col = row.column()
        col.prop(context.scene, "dlv_bool")
        col = row.column()
        col.prop(context.scene, "uv_bool")
        col = row.column()                       
        col.prop(context.scene, "drv_bool")
        row = layout.row()
        col = row.column()                       
        col.separator()
        self.layout.prop(context.scene, "draw_distance")
        row = layout.row()
        col = row.column()                       
        col.separator()
        self.layout.operator("apply.apply", icon='ADD')
        self.layout.operator("update.update", icon='FILE_REFRESH')
        row = layout.row()
        col = row.column()                       
        col.separator()
        layout.label(text="Camera:", icon='VIEW_CAMERA')
        self.layout.prop(context.scene, "Collection")
        self.layout.operator("cam.cam", icon='ADD')
        row = layout.row()
        col = row.column()                       
        col.separator()
        layout.label(text="Sheets:", icon='RENDERLAYERS')
        self.layout.prop(context.scene, "format_type")
        self.layout.operator("format.format", icon='ADD')
        row = layout.row()
        col = row.column()
        col.separator()
        layout.label(text="Settings for render", icon='PREFERENCES')
        layout.label(text="Choose:")
        self.layout.prop(context.scene, "Sheets")
        self.layout.prop(context.scene, "Camera")
        self.layout.operator("sfrender.sfrender", icon='SETTINGS')
        
 
    def execute(self, context):
        
    #    print("lolo")
    #    if self.fv_bool:
    #        self.fv_bool = False
        return {'FINISHED'}

classes = [
    OBJECT_OT_ApplyButton,
    OBJECT_OT_UpdateButton,
    OBJECT_OT_AddCameraButton,
    OBJECT_OT_FormatButton,
    OBJECT_OT_SFRenderButton,
    OB_PT_LSToolsPanel,
]

#register, unregister = bpy.utils.register_classes_factory(classes)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)    

def unregister():    
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)


if __name__ == "__main__":
    register()